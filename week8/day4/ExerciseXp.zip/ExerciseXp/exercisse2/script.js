let winBattle = () => true;
const experiencePoints = winBattle() ? 10 : 1;
console.log(experiencePoints);
